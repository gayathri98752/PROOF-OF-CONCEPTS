import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ReceiptUiComponent } from './receipt-ui.component';

describe('ReceiptUiComponent', () => {
  let component: ReceiptUiComponent;
  let fixture: ComponentFixture<ReceiptUiComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [ReceiptUiComponent]
    });
    fixture = TestBed.createComponent(ReceiptUiComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
