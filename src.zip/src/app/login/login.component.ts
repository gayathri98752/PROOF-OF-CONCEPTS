import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, ReactiveFormsModule } from '@angular/forms';
import { LoginService } from '../services/login.service';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css'],
})
export class LoginComponent implements OnInit {
  constructor(private _fb: FormBuilder, private loginService: LoginService) {}

  loginForm: FormGroup = this._fb.group({});

  ngOnInit(): void {
    this.loginForm = this._fb.group({
      email: ['admin@gmail.com'],
      password: ['Admin@123'],
    });
  }

  login() {
    this.loginService.login(this.loginForm.value).subscribe({
      next: (res) => {
        console.log('Redirecting to dashboard', res);
        // Redirect to dashboard here
        this.loginService.navRoute('/sdvs/dashboard');
      },
      complete: () => {
        console.log('Login request completed');
      },
      error: (error) => {
        console.error('Error in login request', error);
      },
    });
  }
}
